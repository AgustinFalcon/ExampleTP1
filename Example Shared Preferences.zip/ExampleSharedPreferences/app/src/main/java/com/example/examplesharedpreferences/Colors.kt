package com.example.examplesharedpreferences

enum class Colors {
    RED,
    BLUE,
    GREEN,
    YELLOW,
    GRAY
}